CREATE FUNCTION getAverageOfScores(assessmentID INT, moduleID INT)
  RETURNS INT
  BEGIN
	DECLARE res INT;
    
    #Here I query to get the average of the scores and time it by 20 (as the score field only goes to 5)
    #I filter by module and if the result field is empty
	SELECT AVG(score) * 20 INTO res FROM scores WHERE fk_module = moduleID AND fk_result IS NULL;
    
    #When i have calculated the average score, i will update the result field, so that it can
    #no longer count towards a new assessment
    UPDATE scores SET fk_result = assessmentID WHERE fk_module = moduleID AND fk_result IS NULL;
    
    #If there is no scores for a module, then you get a null, I prevented this by using an if statement and setting a variable to return.
    IF res IS NULL THEN
		SET res = 0;
	END IF;
    
    RETURN res;
END;
