CREATE FUNCTION GetModuleByIdAndCompany(moduleID INT, companyID INT)
  RETURNS INT
  BEGIN
	DECLARE mID INT;
	
    #its very simple, i search for the module id based on the module id from the moduletype table and company ID.
	SELECT id INTO mID FROM module WHERE module.fk_module = moduleID AND module.fk_company = companyID;
	
    #I then return it.
    RETURN mID;
END;
