CREATE PROCEDURE getApprovedOrNotApprovedAssessmentsAfterADate(IN newDate DATE, IN approvedA INT)
  BEGIN
	
	IF approvedA = 0 THEN
		SELECT * FROM assessment
        WHERE date > newDate AND approved = 0; 
	
    ELSEIF approvedA = 1 THEN
		SELECT * FROM assessment
        WHERE date > newDate AND approved = 1;
        
	ELSE
		SELECT "Please select 0 or 1";
		
	END IF;
END;
