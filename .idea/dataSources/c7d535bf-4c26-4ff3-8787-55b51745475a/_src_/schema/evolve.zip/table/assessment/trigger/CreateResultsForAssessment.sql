CREATE TRIGGER CreateResultsForAssessment
AFTER INSERT ON assessment
FOR EACH ROW
  BEGIN

#Settings variables
DECLARE module1 INT;
DECLARE module2 INT;
DECLARE module3 INT;
DECLARE module4 INT;
DECLARE module5 INT;

DECLARE avg1 INT;
DECLARE avg2 INT;
DECLARE avg3 INT;
DECLARE avg4 INT;
DECLARE avg5 INT;

#Settings variables with functions
SET module1 = GetModuleByIdAndCompany(1, new.fk_company);
SET module2 = GetModuleByIdAndCompany(2, new.fk_company);
SET module3 = GetModuleByIdAndCompany(3, new.fk_company);
SET module4 = GetModuleByIdAndCompany(4, new.fk_company);
SET module5 = GetModuleByIdAndCompany(5, new.fk_company);

SET avg1 = GetAverageOfScores(NEW.id, module1);
SET avg2 = GetAverageOfScores(NEW.id, module2);
SET avg3 = GetAverageOfScores(NEW.id, module3);
SET avg4 = GetAverageOfScores(NEW.id, module4);
SET avg5 = GetAverageOfScores(NEW.id, module5);

#Applying the data to the results table
INSERT INTO result (fk_assessment, fk_module, score, fk_company) VALUES (NEW.id, module1, avg1, NEW.fk_company);
INSERT INTO result (fk_assessment, fk_module, score, fk_company) VALUES (NEW.id, module2, avg2, NEW.fk_company);
INSERT INTO result (fk_assessment, fk_module, score, fk_company) VALUES (NEW.id, module3, avg3, NEW.fk_company);
INSERT INTO result (fk_assessment, fk_module, score, fk_company) VALUES (NEW.id, module4, avg4, NEW.fk_company);
INSERT INTO result (fk_assessment, fk_module, score, fk_company) VALUES (NEW.id, module5, avg5, NEW.fk_company);

END;
