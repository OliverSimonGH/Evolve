CREATE TRIGGER insertModulesForCompany
AFTER INSERT ON company
FOR EACH ROW
  BEGIN
INSERT INTO module (fk_company, fk_module) VALUES (NEW.id, 1);
INSERT INTO module (fk_company, fk_module) VALUES (NEW.id, 2);
INSERT INTO module (fk_company, fk_module) VALUES (NEW.id, 3);
INSERT INTO module (fk_company, fk_module) VALUES (NEW.id, 4);
INSERT INTO module (fk_company, fk_module) VALUES (NEW.id, 5);
END;
